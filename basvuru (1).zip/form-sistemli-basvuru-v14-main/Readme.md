License
Its protected by Creative Commons [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/)
![image](https://user-images.githubusercontent.com/93944142/185602903-c4d9f3fb-995c-4532-b1d5-c25244ccf22f.png)
